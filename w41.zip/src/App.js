
import './App.css';
import Interval from './Interval';

function App() {
  return (
    <div className="App">
      w41
      <Interval />
    </div>
  );
}

export default App;
